<?php

namespace App\Models;

use JWTAuth;
use App\Models\Tags;
use App\Models\User;
use App\Models\Company;
use App\Models\Remarks;
use App\Models\Projects;
use App\Models\Interests;
use App\Models\QueryWall;
use App\Models\Advertisings;
use App\Models\Notifications;
use App\Models\TendersVersions;
use App\Models\TendersCompanies;
use Illuminate\Database\Eloquent\Model;
use App\Transformers\TendersTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Tenders extends Model
{
    use HasFactory;

    public $transformer = TendersTransformer::class;

    const TYPE_PUBLIC   = 'Publico';
    const TYPE_PRIVATE  = 'Privado';

    protected $fillable = [
        'name',
        'description',
        'project_id',
        'company_id',
        'user_id',
        'type'
    ];

    public function validateUser()
    {
        try {
            $this->user = JWTAuth::parseToken()->authenticate();
        } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
        }
        return $this->user;
    }

    public function project()
    {
        return $this->belongsTo(Projects::class);
    }

    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relacion uno a muchos polimorfica
    public function querywalls()
    {
        return $this->morphMany(QueryWall::class, 'querysable');
    }

    // Nuevo
    public function tenderCategories()
    {
        return $this->belongsToMany(Category::class);
    }

    public function tendersVersion()
    {
        return $this->hasMany(TendersVersions::class);
    }

    public function tenderCompaniesIds()
    {
        return TendersCompanies::where('tender_id', $this->id)->pluck('company_id');
    }

    // Relacion uno a muchos polimorfica
    public function advertisings()
    {
        return $this->morphMany(Advertisings::class, 'advertisingable');
    }

    public function tendersVersionLast()
    {
        if (count($this->tendersVersion) && $this->tendersVersion[0]) {
            return $this->tendersVersion[count($this->tendersVersion) - 1];
        }

        return [];
    }

    public function tendersVersionLastPublishTags()
    {
        $tenderVersionLastPublish = $this->tendersVersionLastPublish();
        if ($tenderVersionLastPublish) {
            $tags = Tags::where('tagsable_id', $tenderVersionLastPublish->id)
                ->where('tagsable_type', TendersVersions::class)
                ->take(3)
                ->orderBy('name', 'asc')
                ->pluck('name');

            return $tags;
        }
        return [];
    }

    public function tendersVersionLastPublish()
    {
        $tenderPublish = $this->tendersVersion
            ->where('status', '<>', TendersVersions::LICITACION_CREATED)
            ->sortBy([['created_at', 'desc']]);

        if ($tenderPublish && $tenderPublish->count()) {
            return $tenderPublish->first();
        }

        return [];
    }

    public function tenderCompanies()
    {
        return $this->hasMany(TendersCompanies::class, 'tender_id');
    }

    public function tenderCompaniesActive()
    {
        return TendersCompanies::where('tender_id', $this->id)
            ->where('status', TendersCompanies::STATUS_PARTICIPATING)
            ->get();
    }

    public function tenderCompaniesId()
    {
        return TendersCompanies::where('tender_id', $this->id)
            ->pluck('company_id');
    }

    public function isWinner()
    {
        $tenderVersion = TendersCompanies::where('tender_id', $this->id)
            ->where('winner', TendersCompanies::WINNER_TRUE)
            ->exists();

        return $tenderVersion;
    }

    // Relacion uno a muchos polimorfica
    public function notifications()
    {
        return $this->morphMany(Notifications::class, 'notificationsable');
    }

    // Relacion uno a muchos polimorfica
    public function remarks()
    {
        return $this->morphMany(Remarks::class, 'remarksable');
    }

    // Relacion uno a muchos polimorfica
    public function interests()
    {
        return $this->morphMany(Interests::class, 'interestsable');
    }

    public function tenderStatusUser()
    {
        $status = Tenders::select('tenders_companies.status')
            ->where('tenders.id', $this->id)
            ->join('tenders_companies', 'tenders_companies.tender_id', '=', 'tenders.id')
            ->where('tenders_companies.company_id', $this->validateUser()->companyId())
            ->value('tenders_companies.status');

        return $status;
    }

    public function commissionedUsers()
    {
        return array_unique([$this->company->user->id, $this->user_id]);
    }

    public function participatingUsers()
    {
        $tenderCompanies = TendersCompanies::where('tender_id', $this->id)
            ->get();

        $users = [];
        foreach ($tenderCompanies as $company) {
            $users[] = $company->user_company_id;
            $users[] = $company->company->user->id;
        }

        return  $users;
    }

    // *Devuvle los correos de los usuarios participantes de la licitación.
    public function TenderParticipatingCompanyEmails()
    {
        $emails = [];

        $tenderCompanies = TendersCompanies::where('tender_id', $this->id)
            ->where('status', TendersCompanies::STATUS_PARTICIPATING)
            ->get();


        foreach ($tenderCompanies as $tenderCompany) {
            $emails[] = $tenderCompany->userCompany->email;
            $emails[] = $tenderCompany->company->user->email;
        }

        return array_unique($emails);
    }

    // *Devuelve los id/s de los usuarios participantes de la licitación.
    public function TenderParticipatingCompanyIdUsers()
    {
        $ids = [];

        $tenderCompanies = TendersCompanies::where('tender_id', $this->id)
            ->where('status', TendersCompanies::STATUS_PARTICIPATING)
            ->get();


        foreach ($tenderCompanies as $tenderCompany) {
            $ids[] = $tenderCompany->userCompany->id;
            $ids[] = $tenderCompany->company->user->id;
        }

        return array_unique($ids);
    }

    // *Devuelve los id/s de los usuarios participantes y no de la licitación.
    public function TenderCompanyIdUsers()
    {
        $ids = [];

        $tenderCompanies = TendersCompanies::where('tender_id', $this->id)
            ->get();


        foreach ($tenderCompanies as $tenderCompany) {
            $ids[] = $tenderCompany->userCompany->id;
            $ids[] = $tenderCompany->company->user->id;
        }

        return array_unique($ids);
    }

    // *Devuelve los id/s de administrador de la compañia y del ecargado de la licitación.
    public function TenderAdminIdUsers()
    {
        $ids = [
            $this->company->user->id,
            $this->user->id,
        ];

        return array_unique($ids);
    }

    // *Devuelve los correos del administrador de la compañia y encargado de la licitación.
    public function TenderAdminEmails()
    {
        $emails = [
            $this->company->user->email,
            $this->user->email,
        ];

        return array_unique($emails);
    }

    public function tendersCompaniesParticipating()
    {
        return TendersCompanies::where('tender_id', $this->id)
            ->where('status', TendersCompanies::STATUS_PARTICIPATING)
            ->get();
    }

    public function tendersCompaniesParticipatingName()
    {
        $companies =  TendersCompanies::select('companies.id','companies.name')->where('tenders_companies.tender_id', $this->id)
            ->where('tenders_companies.status', TendersCompanies::STATUS_PARTICIPATING)
            ->join('companies', 'companies.id', '=', 'tenders_companies.company_id')
            ->get();

        foreach ($companies as $value) {
            $value['image'] = $this->companyImage($value->id);
        }

        return $companies;
    }

    public function companyImage($company_id)
    {
        return Company::find($company_id)->image;
    }

    public function UserParticipateTender()
    {
        $participate = [];
        $companies =  TendersCompanies::where('tenders_companies.tender_id', $this->id)
            ->where('tenders_companies.status', TendersCompanies::STATUS_PARTICIPATING)
            ->join('companies', 'companies.id', '=', 'tenders_companies.company_id')
            ->get();

        foreach ($companies as $value)
        {
            $users['id']            = $value->company->user->id;
            $users['image']         = isset($value->company->user->image) ? $value->company->user->image->url: null ;
            $users['company']       = $value->company->name;
            $participate[]          = $users;

            $users['id']            = $value->tender->user->id;
            $users['image']         = isset($value->tender->user->image) ? $value->tender->user->image->url: null ;
            $users['company']       = $value->tender->company->name;
            $participate[]          = $users;

            if($value->company->user->id != $value->userCompany->id)
            {
                $users['id']            = $value->userCompany->id;
                $users['image']         = isset($value->userCompany->image) ? $value->userCompany->image->url: null ;
                $users['company']       = $value->userCompany->companyFull()->name;
                $participate[]          = $users;
            }
        }

        return (count($participate)>0)? $participate : null;
    }
}
