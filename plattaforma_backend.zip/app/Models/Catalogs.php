<?php

namespace App\Models;

use App\Models\Tags;
use App\Models\Image;
use App\Models\Files;
use Illuminate\Database\Eloquent\Model;
use App\Transformers\CatalogTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Catalogs extends Model
{
    use HasFactory;

    const CATALOG_ERASER  = 'Borrador';
    const CATALOG_PUBLISH = 'Publicado';

    public $transformer = CatalogTransformer::class;

    protected $fillable = [
        'name',
        'description_short',
        'description',
        'status',
        'user_id',
        'company_id'
    ];

    public function isPublish(){
        return $this->status == Catalogs::CATALOG_PUBLISH;
    }

    public function company(){
        return $this->belongsTo(Company::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    // Relacion uno a uno polimorfica
    public function image(){
        return $this->morphOne(Image::class, 'imageable');
    }

    // Relacion uno a muchos polimorfica
    public function files(){
        return $this->morphMany(Files::class, 'filesable');
    }

    // Relacion uno a muchos polimorfica
    public function tags()
    {
        return $this->morphMany(Tags::class, 'tagsable');
    }

    public function tagsLimit()
    {
        return ($this->morphMany(Tags::class, 'tagsable'))->take(4);

        // return Tags::where('tagsable_type',Catalogs::class)
        //     ->where('tagsable_id',$this->id)
        //     ->get()
        //     ->take(4); 
    }
}
