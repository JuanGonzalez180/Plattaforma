<div style="padding: 20px; text-align: center;">Si requieres capacitación contáctanos:</div>
  <div style="text-align: center; color: black; font-size: 15px;">
    <a href="mailto:soporte@plattaforma.com" style="text-decoration:none;color: black">
      <img style="width: 20px;" src="https://backend.plattaforma.com/images/iconos/mail.png"/>&nbsp;soporte@plattaforma.com&nbsp;
    </a>
    <a href="https://wa.me/50766094872" style="text-decoration:none;color: black">
      <img style="width: 20px;" src="https://backend.plattaforma.com/images/iconos/whatsapp.png"/>&nbsp;+507&nbsp;6609-4872&nbsp;
    </a>
  </div>
  <div style="color: #999; padding: 20px 30px;">
    <div>Gracias!</div>
    <div>Equipo <a style="color: #171717; text-decoration: none;" href="#">Plattaforma</a></div>
  </div>