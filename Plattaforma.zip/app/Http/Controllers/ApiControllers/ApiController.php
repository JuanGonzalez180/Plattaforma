<?php

namespace App\Http\Controllers\ApiControllers;

use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ApiController extends Controller
{
    //
    use ApiResponser;
}