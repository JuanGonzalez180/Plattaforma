  
        <div style="padding: 20px;">Si presentas problemas, contáctanos: <a style="color: #171717; text-decoration: none;" href="mailto:plattaforma@incdustry.com">plattaforma@incdustry.com</a></div>
    </div>
    <div style="color: #999; padding: 20px 30px;">
        <div>Gracias!</div>
        <div>Equipo <a style="color: #171717; text-decoration: none;" href="#">Plattaforma</a></div>
    </div>
</div>