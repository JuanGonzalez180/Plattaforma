<?php

namespace App\Http\Controllers\WebControllers\scripts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DeleteFilesNotExistController extends Controller
{
    public $routeFile       = 'storage/';
}
