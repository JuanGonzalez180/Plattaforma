<?php

use App\Models\Brands;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBrandsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('brands', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->unsigned();
            $table->string('name')->unique();
            $table->string('status')->default(Brands::BRAND_DISABLED);
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users');
        });

        // Brands::create([
        //     'user_id' => 1,
        //     'name' => 'Sin Marca', 
        //     'status' => 'true'
        // ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('brands');
    }
}
