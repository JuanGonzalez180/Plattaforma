<div style="max-width: 560px; padding: 20px; background: #ffffff; border-radius: 5px; margin: 40px auto; font-family: Open Sans,Helvetica,Arial; font-size: 15px; color: #666;">
    <div style="color: #ffffff; font-weight: normal;">
        <div style="text-align: center; font-weight: 600; font-size: 26px; padding: 20px 0; border-bottom: solid 3px #eeeeee; background: #02113B;"><img src="http://incdustry.com/diseno/plattaforma/logo-plattaforma.png" width="190" /></div>
        <div style="clear: both;"> </div>
    </div>
    <div style="padding: 0 30px 30px 30px; border-bottom: 3px solid #eeeeee;">