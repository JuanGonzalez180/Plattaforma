@extends('layout')

@section('title')
    Editar Producto
@endsection

@section('content')
    @include('partials.structure.open-main')
        
    @include('partials.structure.close-main')
@endsection