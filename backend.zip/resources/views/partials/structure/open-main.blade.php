<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4 d-flex justify-content-center">
    <div class="col-xs-12 col-md-12 col-lg-8">