<div class="form-group col-md-12">
    <label for="productname">Nombre:</label>
    <input type="text" class="form-control" name="name" placeholder="Ingrese el nombre del producto">
</div>
